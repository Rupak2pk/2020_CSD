// Ella Adam    1/6/2021

document.getElementById("button1").onclick = function() {
    document.getElementById("click_it").innerHTML = "You clicked the button!";
}